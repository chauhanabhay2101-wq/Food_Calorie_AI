# Food Calorie AI

Upload a photo of a meal and get the **dish name**, an **estimated calorie range**, and a **recipe suggestion**.
Multimodal project: vision (image classification) + NLP (recipe retrieval with sentence embeddings).

> Calorie values are rough estimates. Portion size, oil and cooking method change the real number.

## Status

- [x] Day 1: repo, config, data pipeline, dataset split
- [ ] Day 2: baseline classifier (EfficientNet-B0, frozen backbone)
- [ ] Day 3: fine-tuning, metrics, Grad-CAM
- [ ] Day 4: nutrition table
- [ ] Day 5: recipe retrieval (sentence-transformers + FAISS)
- [ ] Day 6: Gradio app
- [ ] Day 7: real-world test, deployment, final README

## Project structure

```
food-calorie-ai/
├── config.yaml            # all settings in one place
├── requirements.txt
├── notebooks/
│   └── day1_data_setup.ipynb
├── src/
│   ├── utils.py           # config loading, seeding, device
│   └── data.py            # manifest, splits, transforms, DataLoaders
├── data/
│   ├── raw/               # downloaded images (git-ignored)
│   └── splits/            # train.csv, val.csv, test.csv, classes.json
└── README.md
```

## Dataset

Indian Food Images (Kaggle: `iamsouravbanerjee/indian-food-images-dataset`).
Check the dataset page for its license before publishing anything built on it.

## Quick start (Colab)

1. Runtime -> Change runtime type -> **T4 GPU**.
2. Open `notebooks/day1_data_setup.ipynb` and run all cells.
3. The notebook downloads the data, builds stratified 70/15/15 splits, and shows a training batch.

## Run locally

```bash
pip install -r requirements.txt
python -c "from src.utils import load_config; from src.data import prepare_data; \
cfg = load_config(); print(prepare_data(cfg)[3][:5])"
```

## Results

_To be filled in as the project progresses._

## Limitations

_To be filled in on Day 7 (failure cases, real-world accuracy drop, portion-size uncertainty)._
