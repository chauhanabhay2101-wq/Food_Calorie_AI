"""Data pipeline: find images, build a manifest, make stratified splits, load batches.

Folder layout expected (one sub-folder per dish class):

    some_root/
        biryani/  img1.jpg img2.jpg ...
        dosa/     ...
"""
import json
from pathlib import Path

import pandas as pd
from PIL import Image
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


# --------------------------------------------------------------------------
# 1. Find the folder that actually holds the class sub-folders
# --------------------------------------------------------------------------
def _count_image_files(folder, exts):
    return sum(1 for p in folder.iterdir() if p.is_file() and p.suffix.lower() in exts)


def find_image_root(base_dir, exts=(".jpg", ".jpeg", ".png", ".webp")):
    """Walk base_dir and return the directory with the most class sub-folders.

    Kaggle zips are often nested (e.g. 'Indian Food Images/Indian Food Images/...'),
    so we pick the directory that has the most children containing images.
    """
    exts = {e.lower() for e in exts}
    base_dir = Path(base_dir)
    best_dir, best_score = None, 0
    for d in [base_dir, *[p for p in base_dir.rglob("*") if p.is_dir()]]:
        score = sum(1 for c in d.iterdir() if c.is_dir() and _count_image_files(c, exts) > 0)
        if score > best_score:
            best_dir, best_score = d, score
    if best_dir is None:
        raise FileNotFoundError(f"No class folders with images found under {base_dir}")
    return best_dir


# --------------------------------------------------------------------------
# 2. Manifest: one row per image -> (path, label)
# --------------------------------------------------------------------------
def build_manifest(image_root, exts=(".jpg", ".jpeg", ".png", ".webp"), min_images=10, verify=True):
    """Scan class folders and return a DataFrame with columns: path, label.

    Classes with fewer than `min_images` images are dropped.
    If verify=True, unreadable/corrupt images are skipped and counted.
    """
    exts = {e.lower() for e in exts}
    image_root = Path(image_root)
    rows, skipped = [], 0
    for class_dir in sorted(p for p in image_root.iterdir() if p.is_dir()):
        files = [f for f in sorted(class_dir.iterdir()) if f.is_file() and f.suffix.lower() in exts]
        if len(files) < min_images:
            continue
        for f in files:
            if verify:
                try:
                    with Image.open(f) as im:
                        im.verify()
                except Exception:
                    skipped += 1
                    continue
            rows.append({"path": str(f), "label": class_dir.name})
    if not rows:
        raise ValueError("Manifest is empty - check raw_dir and min_images_per_class in config.yaml")
    df = pd.DataFrame(rows)
    # drop classes that fell under the threshold after removing corrupt files
    counts = df["label"].value_counts()
    df = df[df["label"].isin(counts[counts >= min_images].index)].reset_index(drop=True)
    df.attrs["skipped_corrupt"] = skipped
    return df


# --------------------------------------------------------------------------
# 3. Stratified train / val / test split (saved as CSV so runs are reproducible)
# --------------------------------------------------------------------------
def make_splits(df, train=0.70, val=0.15, test=0.15, seed=42):
    """Split so each class keeps the same proportions in every subset."""
    assert abs(train + val + test - 1.0) < 1e-6, "split ratios must sum to 1"
    train_df, rest_df = train_test_split(
        df, test_size=(val + test), stratify=df["label"], random_state=seed
    )
    val_df, test_df = train_test_split(
        rest_df, test_size=test / (val + test), stratify=rest_df["label"], random_state=seed
    )
    return (
        train_df.reset_index(drop=True),
        val_df.reset_index(drop=True),
        test_df.reset_index(drop=True),
    )


def save_splits(train_df, val_df, test_df, out_dir):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    train_df.to_csv(out_dir / "train.csv", index=False)
    val_df.to_csv(out_dir / "val.csv", index=False)
    test_df.to_csv(out_dir / "test.csv", index=False)
    classes = sorted(train_df["label"].unique().tolist())
    with open(out_dir / "classes.json", "w", encoding="utf-8") as f:
        json.dump(classes, f, indent=2, ensure_ascii=False)
    return classes


def load_splits(split_dir):
    split_dir = Path(split_dir)
    train_df = pd.read_csv(split_dir / "train.csv")
    val_df = pd.read_csv(split_dir / "val.csv")
    test_df = pd.read_csv(split_dir / "test.csv")
    with open(split_dir / "classes.json", encoding="utf-8") as f:
        classes = json.load(f)
    return train_df, val_df, test_df, classes


# --------------------------------------------------------------------------
# 4. Transforms, Dataset, DataLoaders
# --------------------------------------------------------------------------
def get_transforms(size=224, mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)):
    """Return (train_tfms, eval_tfms). Train gets augmentation; eval does not."""
    train_tfms = transforms.Compose(
        [
            transforms.RandomResizedCrop(size, scale=(0.7, 1.0)),
            transforms.RandomHorizontalFlip(),
            transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ]
    )
    eval_tfms = transforms.Compose(
        [
            transforms.Resize(int(size * 1.14)),
            transforms.CenterCrop(size),
            transforms.ToTensor(),
            transforms.Normalize(mean, std),
        ]
    )
    return train_tfms, eval_tfms


class FoodDataset(Dataset):
    """Reads images listed in a manifest DataFrame (path, label)."""

    def __init__(self, df, class_to_idx, transform=None):
        self.paths = df["path"].tolist()
        self.targets = [class_to_idx[l] for l in df["label"]]
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        img = Image.open(self.paths[i]).convert("RGB")
        if self.transform:
            img = self.transform(img)
        return img, self.targets[i]


def get_dataloaders(cfg, train_df, val_df, test_df, classes):
    """Build train/val/test DataLoaders from the config dict."""
    class_to_idx = {c: i for i, c in enumerate(classes)}
    img = cfg["image"]
    tr_tfms, ev_tfms = get_transforms(img["size"], img["mean"], img["std"])
    bs, nw = cfg["train"]["batch_size"], cfg["train"]["num_workers"]
    train_ds = FoodDataset(train_df, class_to_idx, tr_tfms)
    val_ds = FoodDataset(val_df, class_to_idx, ev_tfms)
    test_ds = FoodDataset(test_df, class_to_idx, ev_tfms)
    return (
        DataLoader(train_ds, batch_size=bs, shuffle=True, num_workers=nw, pin_memory=True),
        DataLoader(val_ds, batch_size=bs, shuffle=False, num_workers=nw, pin_memory=True),
        DataLoader(test_ds, batch_size=bs, shuffle=False, num_workers=nw, pin_memory=True),
    )


# --------------------------------------------------------------------------
# 5. One-call convenience used by the notebook
# --------------------------------------------------------------------------
def prepare_data(cfg, raw_dir=None):
    """Find images -> manifest -> splits -> save CSVs. Returns (train, val, test, classes, image_root)."""
    d = cfg["data"]
    image_root = find_image_root(raw_dir or d["raw_dir"], d["image_extensions"])
    df = build_manifest(image_root, d["image_extensions"], d["min_images_per_class"])
    s = d["splits"]
    train_df, val_df, test_df = make_splits(df, s["train"], s["val"], s["test"], cfg["seed"])
    classes = save_splits(train_df, val_df, test_df, d["split_dir"])
    return train_df, val_df, test_df, classes, image_root
