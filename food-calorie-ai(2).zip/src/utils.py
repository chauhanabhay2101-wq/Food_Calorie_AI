"""Small helpers shared across the project."""
import random
from pathlib import Path

import numpy as np
import yaml


def load_config(path="config.yaml"):
    """Read config.yaml and return it as a dict."""
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def seed_everything(seed=42):
    """Make runs repeatable (python, numpy, and torch if installed)."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass


def get_device():
    """Return 'cuda' when a GPU is available, otherwise 'cpu'."""
    import torch

    return "cuda" if torch.cuda.is_available() else "cpu"


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)
    return Path(path)
